Aqui vai seus códigos "compartilhados", isso é, códigos que todas suas páginas usam.

as classes precisam ser publicas, e todas as funções acessadas de fora da classe também.

exemplo:

public class MinhaClasse {
	
	public init() {

	}
}